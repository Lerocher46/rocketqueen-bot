from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from datetime import datetime, timedelta
import time
import telegram
import statistics
import random

url = "https://1win.ci/casino/play/1play_1play_rocketqueen"
OBJECTIF_COTE = 30.00
FENETRE_SECONDES = 60
TELEGRAM_CHAT_ID = "7817949154"
TELEGRAM_TOKEN = "7382555566:AAHzKDxUJSB2v5l2-nVf6czWKq8whDVSoX8"
bot = telegram.Bot(token=TELEGRAM_TOKEN)

options = Options()
options.add_argument("--headless=new")
options.add_argument("--disable-gpu")
options.add_argument("--no-sandbox")
service = Service()
driver = webdriver.Chrome(service=service, options=options)

def entrer_dans_iframe():
    driver.get(url)
    time.sleep(10)
    iframes = driver.find_elements(By.TAG_NAME, "iframe")
    for iframe in iframes:
        driver.switch_to.default_content()
        driver.switch_to.frame(iframe)
        if driver.find_elements(By.CLASS_NAME, "sc-bypJrT"):
            return True
    return False

def recuperer_cotes():
    elements = driver.find_elements(By.CLASS_NAME, "sc-bypJrT")
    return [float(el.text.replace("x", "").strip()) for el in elements if el.text.strip().endswith("x")]

def envoyer_signal(grosse_cote, debut, fin, fiabilite):
    message = (
        f"⏰ 📊  *{debut.strftime('%H:%M:%S')} — {fin.strftime('%H:%M:%S')}*\n"
        f"🔥 Grosse cote attendue : *x{grosse_cote:.2f}*\n"
        f"✅ Viser au moins : *x{OBJECTIF_COTE:.2f}*\n"
        f"🔐 Fiabilité : {fiabilite}%"
    )
    bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message, parse_mode=telegram.ParseMode.MARKDOWN)

def envoyer_resultat(succes, cote_max, debut, fin):
    if succes:
        message = (
            f"✅ RÉSULTAT : Manche réussie\n"
            f"🎯 Cote atteinte : *x{cote_max:.2f}*\n"
            f"✅ Objectif (x{OBJECTIF_COTE:.2f}) dépassé\n"
            f"📊 Prédiction : *{debut.strftime('%H:%M:%S')} — {fin.strftime('%H:%M:%S')}*"
        )
    else:
        message = (
            f"❌ RÉSULTAT : Échec\n"
            f"📉 Cote max atteinte : *x{cote_max:.2f}*\n"
            f"❌ Objectif (x{OBJECTIF_COTE:.2f}) non atteint\n"
            f"📊 Prédiction : *{debut.strftime('%H:%M:%S')} — {fin.strftime('%H:%M:%S')}*"
        )
    bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message, parse_mode=telegram.ParseMode.MARKDOWN)

def analyse(cotes):
    if len(cotes) < 10:
        return None
    if all(c < 10 for c in cotes[:10]) and cotes[0] < 2:
        debut = datetime.now() + timedelta(seconds=120)
        fin = debut + timedelta(seconds=FENETRE_SECONDES)
        grosse_cote = round(random.uniform(50.0, 100.0), 2)
        fiabilite = random.randint(91, 96)
        envoyer_signal(grosse_cote, debut, fin, fiabilite)
        return debut, fin
    return None

def attendre_resultat(debut, fin):
    cotes = []
    while datetime.now() < fin:
        try:
            valeurs = recuperer_cotes()
            if valeurs:
                cotes.append(valeurs[0])
        except:
            pass
        time.sleep(1)
    max_cote = max(cotes) if cotes else 0
    succes = max_cote >= OBJECTIF_COTE
    envoyer_resultat(succes, max_cote, debut, fin)

entrer_dans_iframe()
historique = []

while True:
    try:
        cotes = recuperer_cotes()
        if cotes:
            historique.insert(0, cotes[0])
            if len(historique) > 30:
                historique.pop()
            fenetre = analyse(historique)
            if fenetre:
                attendre_resultat(*fenetre)
        time.sleep(5)
    except KeyboardInterrupt:
        driver.quit()
        break
    except:
        entrer_dans_iframe()