
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from datetime import datetime, timedelta
import time
import csv
import telegram
import statistics
import random

url = "https://1win.ci/casino/play/1play_1play_rocketqueen"
csv_file = "historique_cotes.csv"
max_stable_duration = 90
check_interval = 1
seuil_repetition = 8
taille_historique = 30
OBJECTIF_COTE = 30.0
FENETRE_SECONDES = 60

TELEGRAM_CHAT_ID = "7817949154"
TELEGRAM_TOKEN = "7382555566:AAHzKDxUJSB2v5l2-nVf6czWKq8whDVSoX8"
bot = telegram.Bot(token=TELEGRAM_TOKEN)

options = Options()
options.add_argument("--headless=new")
options.add_argument("--disable-gpu")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
service = Service()
driver = webdriver.Chrome(service=service, options=options)

def entrer_dans_iframe():
    driver.get(url)
    time.sleep(10)
    iframes = driver.find_elements(By.TAG_NAME, "iframe")
    for iframe in iframes:
        driver.switch_to.default_content()
        driver.switch_to.frame(iframe)
        try:
            if driver.find_elements(By.CLASS_NAME, "sc-bypJrT"):
                return True
        except:
            continue
    return False

def enregistrer_cotes(cotes):
    horodatage = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(csv_file, mode='a', newline='', encoding='utf-8') as fichier:
        writer = csv.writer(fichier)
        writer.writerow([horodatage] + cotes)

def recuperer_cotes():
    elements = driver.find_elements(By.CLASS_NAME, "sc-bypJrT")
    cotes = []
    for el in elements:
        try:
            text = el.text.strip()
            if text.endswith("x"):
                cotes.append(text)
        except:
            continue
    return cotes

def envoyer_signal(grosse_cote, debut, fin, fiabilite):
    message = (
        f"⏰ 📊  *{debut.strftime('%H:%M:%S')} — {fin.strftime('%H:%M:%S')}*\n"
        f"🔥 Grosse cote attendue : *x{grosse_cote:.2f}*\n"
        f"✅ Viser au moins : *x{OBJECTIF_COTE:.2f}* (stratégie spéciale)\n"
        f"🔐 Fiabilité : {fiabilite}%"
    )
    try:
        bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message, parse_mode=telegram.ParseMode.MARKDOWN)
    except Exception as e:
        print(f"Erreur envoi signal : {e}")

def envoyer_resultat(succes, cote_max, debut, fin):
    if succes:
        message = (
            f"✅ RÉSULTAT : Manche réussie\n"
            f"🎯 Cote atteinte : *x{cote_max:.2f}*\n"
            f"✅ Objectif (x{OBJECTIF_COTE:.2f}) dépassé\n"
            f"📊 Prédiction : *{debut.strftime('%H:%M:%S')} — {fin.strftime('%H:%M:%S')}*"
        )
    else:
        message = (
            f"❌ RÉSULTAT : Échec\n"
            f"📉 Cote max atteinte : *x{cote_max:.2f}*\n"
            f"❌ Objectif (x{OBJECTIF_COTE:.2f}) non atteint\n"
            f"📊 Prédiction : *{debut.strftime('%H:%M:%S')} — {fin.strftime('%H:%M:%S')}*"
        )
    try:
        bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message, parse_mode=telegram.ParseMode.MARKDOWN)
    except Exception as e:
        print(f"Erreur envoi résultat : {e}")

def analyser_cotes(cotes_float):
    if len(cotes_float) < 10:
        return None
    grosses = [c for c in cotes_float[:10] if c >= 10]
    if not grosses and cotes_float[0] < 2:
        maintenant = datetime.now()
        debut = maintenant + timedelta(seconds=120)
        fin = debut + timedelta(seconds=FENETRE_SECONDES)
        grosse_cote = round(random.uniform(50.0, 100.0), 2)
        fiabilite = random.randint(91, 96)
        envoyer_signal(grosse_cote, debut, fin, fiabilite)
        return (debut, fin)
    return None

def attendre_resultat(debut, fin):
    cotes_observees = []
    while datetime.now() < fin:
        try:
            cotes = recuperer_cotes()
            if cotes:
                try:
                    cote = float(cotes[0].replace("x", ""))
                    cotes_observees.append(cote)
                except:
                    pass
        except:
            pass
        time.sleep(1)
    if not cotes_observees:
        envoyer_resultat(False, 0, debut, fin)
    else:
        max_cote = max(cotes_observees)
        succes = max_cote >= OBJECTIF_COTE
        envoyer_resultat(succes, max_cote, debut, fin)

print("Démarrage bot...")
entrer_dans_iframe()
derniere_serie = []
dernier_changement = time.time()
cote_precedente = None
repetitions = 0
historique_float = []

try:
    while True:
        time.sleep(check_interval)
        try:
            cotes = recuperer_cotes()
            if cotes:
                derniere_cote = cotes[0]
                if cotes != derniere_serie:
                    enregistrer_cotes(cotes)
                    derniere_serie = cotes
                    dernier_changement = time.time()
                    try:
                        valeur = float(derniere_cote.replace("x", ""))
                        historique_float.insert(0, valeur)
                        if len(historique_float) > taille_historique:
                            historique_float.pop()
                        fenetre = analyser_cotes(historique_float)
                        if fenetre:
                            attendre_resultat(fenetre[0], fenetre[1])
                    except:
                        pass
                if derniere_cote == cote_precedente:
                    repetitions += 1
                else:
                    repetitions = 0
                    cote_precedente = derniere_cote
                if repetitions >= seuil_repetition:
                    driver.switch_to.default_content()
                    entrer_dans_iframe()
                    derniere_serie = []
                    repetitions = 0
                    cote_precedente = None
                    historique_float = []
            else:
                print("Cotes non détectées.")
        except Exception as e:
            print(f"Erreur : {e}")
        if time.time() - dernier_changement > max_stable_duration:
            driver.switch_to.default_content()
            entrer_dans_iframe()
            derniere_serie = []
            dernier_changement = time.time()
            repetitions = 0
            cote_precedente = None
            historique_float = []
except KeyboardInterrupt:
    print("Arrêt manuel.")
    driver.quit()
